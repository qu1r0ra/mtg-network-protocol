"""Real TCP smoke test for the client/server integration layer."""

from __future__ import annotations

import asyncio
import contextlib
import io
import json
import random

from mtgnp.client.__main__ import run_client
from mtgnp.server.engine import GameEngine
from mtgnp.server.state import Lifecycle
from mtgnp.server.transport import TransportServer


def test_two_scripted_clients_reach_in_game_over_real_tcp(tmp_path):
    alice_script = tmp_path / "alice.json"
    bob_script = tmp_path / "bob.json"

    trailing_passes = [{"action": "PASS_PRIORITY"} for _ in range(50)]
    alice_script.write_text(
        json.dumps(
            [
                {
                    "action": "PLAYER_READY",
                    "player_id": "Alice",
                    "deck": [
                        "mountain_001",
                        "mountain_002",
                        "mountain_003",
                        "mountain_004",
                        "lightning_bolt_001",
                        "shock_001",
                        "goblin_guide_001",
                        "flame_slash_001",
                    ],
                },
                {"action": "MULLIGAN_CHOICE", "keep": True},
                *trailing_passes,
            ]
        ),
        encoding="utf-8",
    )
    bob_script.write_text(
        json.dumps(
            [
                {
                    "action": "PLAYER_READY",
                    "player_id": "Bob",
                    "deck": [
                        "forest_001",
                        "forest_002",
                        "forest_003",
                        "forest_004",
                        "giant_growth_001",
                        "grizzly_bears_001",
                        "llanowar_elves_001",
                        "naturalize_001",
                    ],
                },
                {"action": "MULLIGAN_CHOICE", "keep": True},
                *trailing_passes,
            ]
        ),
        encoding="utf-8",
    )

    async def scenario() -> None:
        transport = TransportServer(engine=GameEngine(rng=random.Random(7)))
        server = await transport.start("127.0.0.1", 0)
        port = server.sockets[0].getsockname()[1]
        clients = [
            asyncio.create_task(
                run_client("127.0.0.1", port, False, str(alice_script))
            ),
            asyncio.create_task(
                run_client("127.0.0.1", port, False, str(bob_script))
            ),
        ]

        try:
            for _ in range(500):
                if transport.engine.state.lifecycle is Lifecycle.IN_GAME:
                    break
                await asyncio.sleep(0.001)
            assert transport.engine.state.lifecycle is Lifecycle.IN_GAME
            assert set(transport.engine.state.players) == {"Alice", "Bob"}
        finally:
            for task in clients:
                task.cancel()
            await asyncio.gather(*clients, return_exceptions=True)
            await transport.close()

    with contextlib.redirect_stdout(io.StringIO()):
        asyncio.run(scenario())
